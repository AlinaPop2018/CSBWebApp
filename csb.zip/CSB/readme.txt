
1. create database tables, run : CSB\src\main\resources\scriptDB2.sql
2. copy folder CSB\src\main\resources\CSBconfig to C:\CSBconfig on your pc
3. change connection to db in file C:\CSBconfig\appConf\config.properties
4. http://localhost:8080/CSB/index.html
5. when using the website, click on button "Select", choose file C:\CSBconfig\appData\att.txt
   if you want to insert data in db in automatic