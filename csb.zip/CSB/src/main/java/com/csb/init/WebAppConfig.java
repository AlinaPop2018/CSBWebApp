package com.csb.init;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.tiles3.TilesConfigurer;
import org.springframework.web.servlet.view.tiles3.TilesView;
import org.springframework.web.servlet.view.tiles3.TilesViewResolver;

import com.csb.util.UtilFile;

@Configuration
@ComponentScan("com.csb")
@EnableWebMvc
@EnableTransactionManagement
//@PropertySource("classpath:application.properties")
public class WebAppConfig implements WebMvcConfigurer{

	private static final String PROPERTY_NAME_DATABASE_DRIVER = "db.driver";
	private static final String PROPERTY_NAME_DATABASE_PASSWORD = "db.password";
	private static final String PROPERTY_NAME_DATABASE_URL = "db.url";
	private static final String PROPERTY_NAME_DATABASE_USERNAME = "db.username";
	private static final String PROPERTY_NAME_DATABASE_SCHEMA = "db.schema";

	private static final String PROPERTY_NAME_HIBERNATE_DIALECT = "hibernate.dialect";
	private static final String PROPERTY_NAME_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
	private static final String PROPERTY_NAME_ENTITYMANAGER_PACKAGES_TO_SCAN = "entitymanager.packages.to.scan";
	private static String PATH_CONFIG_DIR ="";
	private static String PATH_DATA_DIR ="";
	private static String PATH_LOG_DIR = "";
	public static String SHEMA_NAME;

	@Resource
	private Environment envOld;

	private Properties envConfigDB;
	private Properties envConfigLOG;

	public WebAppConfig() {
		try {
			System.setProperty("csb.application.conf.dir", "C:\\CSBconfig\\appConf");
			System.setProperty("csb.application.data.dir", "C:\\CSBconfig\\appData");
			System.setProperty("csb.application.log.dir", "C:\\CSBconfig\\appLog");
			
			PATH_CONFIG_DIR = System.getProperty("csb.application.conf.dir");
			String pathConfigFile = PATH_CONFIG_DIR + File.separator + "config.properties";
			System.out.println("pathConfigFile : " + pathConfigFile);
			
			PATH_DATA_DIR = System.getProperty("csb.application.data.dir");
			System.out.println("PATH_DATA_DIR : " + PATH_DATA_DIR);
			
			PATH_LOG_DIR = System.getProperty("csb.application.log.dir");
			String pathLogFile = PATH_CONFIG_DIR + File.separator + "log4j.properties";
			
			envConfigDB = UtilFile.fromFile(pathConfigFile);
			envConfigLOG = UtilFile.fromFile(pathLogFile);
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	

	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();

		dataSource.setDriverClassName(envConfigDB.getProperty(PROPERTY_NAME_DATABASE_DRIVER));
		dataSource.setUrl(envConfigDB.getProperty(PROPERTY_NAME_DATABASE_URL));
		dataSource.setUsername(envConfigDB.getProperty(PROPERTY_NAME_DATABASE_USERNAME));
		dataSource.setPassword(envConfigDB.getProperty(PROPERTY_NAME_DATABASE_PASSWORD));
		dataSource.setSchema(envConfigDB.getProperty(PROPERTY_NAME_DATABASE_SCHEMA));
		return dataSource;
	}

	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
		sessionFactoryBean.setDataSource(dataSource());
		sessionFactoryBean.setPackagesToScan(envConfigDB.getProperty(PROPERTY_NAME_ENTITYMANAGER_PACKAGES_TO_SCAN));
		sessionFactoryBean.setHibernateProperties(hibProperties());
		return sessionFactoryBean;
	}

	private Properties hibProperties() {
		Properties properties = new Properties();
		properties.put(PROPERTY_NAME_HIBERNATE_DIALECT, envConfigDB.getProperty(PROPERTY_NAME_HIBERNATE_DIALECT));
		properties.put(PROPERTY_NAME_HIBERNATE_SHOW_SQL, envConfigDB.getProperty(PROPERTY_NAME_HIBERNATE_SHOW_SQL));
		return properties;
	}

	@Bean
	public HibernateTransactionManager transactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory().getObject());
		return transactionManager;
	}
	
	
	/**
     * Configure TilesConfigurer.
     */
	@Bean
	public TilesConfigurer tilesConfigurer(){
	    TilesConfigurer tilesConfigurer = new TilesConfigurer();
	    tilesConfigurer.setDefinitionsFactoryClass(TilesDefinitionConfig.class);
	    tilesConfigurer.setCheckRefresh(true);
	    TilesDefinitionConfig.addDefinitions();
	    return tilesConfigurer;
	}
	
	@Bean
	public ViewResolver tilesViewResolver() {
		TilesViewResolver tilesViewResolver = new TilesViewResolver();
		tilesViewResolver.setViewClass(TilesView.class);
	    return tilesViewResolver;
	}
	
	/**
	 * Configure ResourceHandlers to serve static resources like CSS/ Javascript
	 * etc...
	 */
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/static/**").addResourceLocations("/static/");
	}
	
	@Bean
	public StandardServletMultipartResolver multipartResolver() {
	    return new StandardServletMultipartResolver();
	}

}
