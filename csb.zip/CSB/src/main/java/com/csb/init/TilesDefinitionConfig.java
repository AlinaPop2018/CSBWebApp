package com.csb.init;

import java.util.HashMap;
import java.util.Map;

import org.apache.tiles.Attribute;
import org.apache.tiles.Definition;
import org.apache.tiles.definition.DefinitionsFactory;
import org.apache.tiles.request.Request;

public class TilesDefinitionConfig implements DefinitionsFactory{

	public TilesDefinitionConfig() {
		// TODO Auto-generated constructor stub
	}
	
	private static final Map<String, Definition> TILES_DEFINITIONS = new HashMap<>();

	@Override
	public Definition getDefinition(String name, Request rqst) {

		return TILES_DEFINITIONS.get(name);
	}

	public static void addDefinitions() {

		// IMPORTANTE !!!
		// il titolo non deve avere lo stesso valore assegnato alla vista
		addDefaultLayoutDefinition("home", "mia lista", "/WEB-INF/pages/home.jsp");
		
		addDefaultLayoutDefinition("Tcsb01RacPreAub/list-form", "h ello", "/WEB-INF/pages/Tcsb01RacPreAub/list-form.jsp");
		addDefaultLayoutDefinition("Tcsb01RacPreAub/edit-form", "h ello", "/WEB-INF/pages/Tcsb01RacPreAub/edit-form.jsp");
		addDefaultLayoutDefinition("Tcsb01RacPreAub/add-form", "h ello", "/WEB-INF/pages/Tcsb01RacPreAub/add-form.jsp");
		
		addDefaultLayoutDefinition("Tcsb02Reg/list-form", "h ello", "/WEB-INF/pages/Tcsb02Reg/list-form.jsp");
		addDefaultLayoutDefinition("Tcsb02Reg/edit-form", "h ello", "/WEB-INF/pages/Tcsb02Reg/edit-form.jsp");
		addDefaultLayoutDefinition("Tcsb02Reg/add-form", "h ello", "/WEB-INF/pages/Tcsb02Reg/add-form.jsp");
		
		addDefaultLayoutDefinition("Tcsb03SimAub/list-form", "h ello", "/WEB-INF/pages/Tcsb03SimAub/list-form.jsp");
		addDefaultLayoutDefinition("Tcsb03SimAub/edit-form", "h ello", "/WEB-INF/pages/Tcsb03SimAub/edit-form.jsp");
		addDefaultLayoutDefinition("Tcsb03SimAub/add-form", "h ello", "/WEB-INF/pages/Tcsb03SimAub/add-form.jsp");
		
		addDefaultLayoutDefinition("Tcsb04Att/list-form", "h ello", "/WEB-INF/pages/Tcsb04Att/list-form.jsp");
		addDefaultLayoutDefinition("Tcsb04Att/edit-form", "h ello", "/WEB-INF/pages/Tcsb04Att/edit-form.jsp");
		addDefaultLayoutDefinition("Tcsb04Att/add-form", "h ello", "/WEB-INF/pages/Tcsb04Att/add-form.jsp");
		
		addDefaultLayoutDefinition("Tcsb05Fto/list-form", "h ello", "/WEB-INF/pages/Tcsb05Fto/list-form.jsp");
		addDefaultLayoutDefinition("Tcsb05Fto/edit-form", "h ello", "/WEB-INF/pages/Tcsb05Fto/edit-form.jsp");
		addDefaultLayoutDefinition("Tcsb05Fto/add-form", "h ello", "/WEB-INF/pages/Tcsb05Fto/add-form.jsp");
		
		addDefaultLayoutDefinition("Tcsb06Per/list-form", "h ello", "/WEB-INF/pages/Tcsb06Per/list-form.jsp");
		addDefaultLayoutDefinition("Tcsb06Per/edit-form", "h ello", "/WEB-INF/pages/Tcsb01RacPreAub/edit-form.jsp");
		addDefaultLayoutDefinition("Tcsb06Per/add-form", "h ello", "/WEB-INF/pages/Tcsb06Per/add-form.jsp");
		
	}

	private static void addDefaultLayoutDefinition(String name, String title, String body) {

		Map<String, Attribute> attributes = new HashMap<>();

		attributes.put("title", new Attribute(title));
		attributes.put("header", new Attribute("/WEB-INF/tiles/template/defaultHeader.jsp"));
		attributes.put("menu", new Attribute("/WEB-INF/tiles/template/defaultMenu.jsp"));
		attributes.put("body", new Attribute(body));
		attributes.put("footer", new Attribute("/WEB-INF/tiles/template/defaultFooter.jsp"));

		Attribute baseTemplate = new Attribute("/WEB-INF/tiles/layouts/defaultLayout.jsp");

		TILES_DEFINITIONS.put(name, new Definition(name, baseTemplate, attributes));
	}

}
