package com.csb.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csb.dao.AbstractDao;

@Service
@Transactional
public abstract class AbstractService<T> {
	
	private AbstractDao<T> daoClass;
	
	protected abstract AbstractDao<T> getEntityDao();
	
	public AbstractService(AbstractDao<T> daoClass) {
        this.daoClass = daoClass;
    }
	
	public void create(T entity) {
		getEntityDao().create(entity);
    }

    public void edit(T entity) {
    	getEntityDao().edit(entity); 
    }
    
    public T find(Object id) {
		return getEntityDao().find(id);
	}

    public void remove(Object id) {
    	getEntityDao().remove(id);
    }

    public List<T> findAll() {
    	List<T> list = new ArrayList<>();
    	list = getEntityDao().findAll();
    	return list; 
    }

    public List<T> findRange(int[] range) {
        return getEntityDao().findRange(range);
    }

    public int count() {
    	return getEntityDao().count();
    }

}
