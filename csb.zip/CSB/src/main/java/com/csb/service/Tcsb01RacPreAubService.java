package com.csb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csb.dao.AbstractDao;
import com.csb.dao.Tcsb01RacPreAubDao;
import com.csb.entity.Tcsb01RacPreAub;

@Service
@Transactional
public class Tcsb01RacPreAubService extends AbstractService<Tcsb01RacPreAub>{

	@Autowired
	private Tcsb01RacPreAubDao tcsb01RacPreAubDao;
	

	public Tcsb01RacPreAubService(AbstractDao<Tcsb01RacPreAub> daoClass) {
		super(daoClass);
	}

	@Override
	@Autowired
	protected AbstractDao<Tcsb01RacPreAub> getEntityDao() {
		return tcsb01RacPreAubDao;
	}

	public Long getMaxProgresivoFile() {
		Long max = tcsb01RacPreAubDao.maxProgresivoFile();
		return max;
    }
	
	public Long getMaxProgresivoElabFile(short fElab) {
		Long maxNonElab = tcsb01RacPreAubDao.maxProgresivoElabFile(fElab);
		return maxNonElab;
	}
	
	public List<Tcsb01RacPreAub> findAllNonElabFile(Long progressivoFile, Short fagElab) {
		return tcsb01RacPreAubDao.findAllNonElabFile(progressivoFile, fagElab);
	}
	
	public void updateFelab(Short fElab, Long pFl) {
		tcsb01RacPreAubDao.updateFelab(fElab, pFl); 
	}
	
	public List findAllNonElab(Short fElab) {
		return tcsb01RacPreAubDao.findAllNonElab(fElab);
	}

}
