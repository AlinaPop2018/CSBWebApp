package com.csb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csb.dao.AbstractDao;
import com.csb.dao.Tcsb04AttDao;
import com.csb.entity.Tcsb04Att;

@Service
@Transactional
public class Tcsb04AttService extends AbstractService<Tcsb04Att> {
	
	@Autowired
	private Tcsb04AttDao tcsb04AttDao;
	

	public Tcsb04AttService(AbstractDao<Tcsb04Att> daoClass) {
		super(daoClass);
	}

	@Override
	@Autowired
	protected AbstractDao<Tcsb04Att> getEntityDao() {
		return tcsb04AttDao;
	}

}
