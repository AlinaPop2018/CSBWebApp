package com.csb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csb.dao.AbstractDao;
import com.csb.dao.Tcsb02RegDao;
import com.csb.entity.Tcsb02Reg;
import com.csb.entity.Tcsb04Att;
import com.csb.entity.Tcsb05Fto;

@Service
@Transactional
public class Tcsb02RegService extends AbstractService<Tcsb02Reg> {

	@Autowired
	private Tcsb02RegDao tcsb02RegDao;
	

	public Tcsb02RegService(AbstractDao<Tcsb02Reg> daoClass) {
		super(daoClass);
	}

	@Override
	@Autowired
	protected AbstractDao<Tcsb02Reg> getEntityDao() {
		return tcsb02RegDao;
	}
	
	public String findByCAtt(Tcsb04Att tcsb04Att, Tcsb05Fto tcsb05Fto) {
		return tcsb02RegDao.findByCAtt(tcsb04Att, tcsb05Fto);
	}
	
	public List<Tcsb02Reg> findByCFto(Tcsb05Fto tcsb05Fto) {
		return tcsb02RegDao.findByCFto(tcsb05Fto);
	}
	
	public String findByCFtoTDesAtt(String cFto, String tDesAtt) {
		return tcsb02RegDao.findByCFtoTDesAtt(cFto, tDesAtt);
	}

}
