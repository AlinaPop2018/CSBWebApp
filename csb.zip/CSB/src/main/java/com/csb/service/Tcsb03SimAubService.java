package com.csb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csb.dao.AbstractDao;
import com.csb.dao.Tcsb03SimAubDao;
import com.csb.entity.Tcsb01RacPreAub;
import com.csb.entity.Tcsb03SimAub;

@Service
@Transactional
public class Tcsb03SimAubService extends AbstractService<Tcsb03SimAub> {
	@Autowired
	private Tcsb03SimAubDao tcsb03SimAubDao;
	

	public Tcsb03SimAubService(AbstractDao<Tcsb03SimAub> daoClass) {
		super(daoClass);
	}

	@Override
	@Autowired
	protected AbstractDao<Tcsb03SimAub> getEntityDao() {
		return tcsb03SimAubDao;
	}
	
	public List<Tcsb03SimAub> findAllElabFile(Long progressivoFile) {
		return tcsb03SimAubDao.findAllElabFile(progressivoFile);
	}
}
