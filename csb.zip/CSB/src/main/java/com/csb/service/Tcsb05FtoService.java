package com.csb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csb.dao.AbstractDao;
import com.csb.dao.Tcsb05FtoDao;
import com.csb.entity.Tcsb05Fto;

@Service
@Transactional
public class Tcsb05FtoService extends AbstractService<Tcsb05Fto> {

	@Autowired
	private Tcsb05FtoDao tcsb05FtoDao;
	

	public Tcsb05FtoService(AbstractDao<Tcsb05Fto> daoClass) {
		super(daoClass);
	}

	@Override
	@Autowired
	protected AbstractDao<Tcsb05Fto> getEntityDao() {
		return tcsb05FtoDao;
	}
}
