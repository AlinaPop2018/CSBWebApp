package com.csb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.csb.dao.AbstractDao;
import com.csb.dao.Tcsb06PerDao;
import com.csb.entity.Tcsb06Per;

@Service
@Transactional
public class Tcsb06PerService extends AbstractService<Tcsb06Per> {
	
	@Autowired
	private Tcsb06PerDao tcsb06PerDao;
	

	public Tcsb06PerService(AbstractDao<Tcsb06Per> daoClass) {
		super(daoClass);
	}

	@Override
	@Autowired
	protected AbstractDao<Tcsb06Per> getEntityDao() {
		return tcsb06PerDao;
	}

}
