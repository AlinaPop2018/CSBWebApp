package com.csb.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.csb.entity.Tcsb01RacPreAub;
import com.csb.entity.Tcsb02Reg;
import com.csb.entity.Tcsb03SimAub;
import com.csb.entity.Tcsb04Att;
import com.csb.entity.Tcsb05Fto;
import com.csb.service.AbstractService;
import com.csb.service.Tcsb01RacPreAubService;
import com.csb.service.Tcsb02RegService;
import com.csb.service.Tcsb03SimAubService;
import com.csb.util.SimulaFleAubay;
import com.csb.util.UtilFile;

@Controller
@RequestMapping(value="/tcsb03SimAub")
public class Tcsb03SimAubController extends AbstractController<Tcsb03SimAub>{
	
	private static final Logger logger = LogManager.getLogger(Tcsb03SimAubController.class);

	@Autowired
	private Tcsb03SimAubService tcsb03SimAubService;
	
	@Autowired
	private Tcsb02RegService tcsb02RegService;
	
	@Autowired
	private Tcsb01RacPreAubService tcsb01RacPreAubService;
	
	private String nameAddFormJSP = "Tcsb03SimAub/add-form";
	private String nameEditFormJSP = "Tcsb03SimAub/edit-form";
	private String nameListFormJSP = "Tcsb03SimAub/list-form";
	private String nameEntity ="Tcsb03SimAub";
	
	private Tcsb03SimAub entityName = new Tcsb03SimAub();
	
	@RequestMapping(value="/simulaFile", method=RequestMethod.GET)
	public ModelAndView readFileAndInsert(HttpServletResponse response, @ModelAttribute Tcsb01RacPreAub entity) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		
		List<Tcsb01RacPreAub> tcsb01RacPreAubListNONELAB = tcsb01RacPreAubService.findAllNonElab((short)0);
				
		if (tcsb01RacPreAubListNONELAB.isEmpty()) {
			Short fagElab = 1;
			Long progressivoFileElab = tcsb01RacPreAubService.getMaxProgresivoElabFile(fagElab);
			List<Tcsb03SimAub> tcsb03SimAubList = tcsb03SimAubService.findAllElabFile(progressivoFileElab);
			List<SimulaFleAubay> simulaFleAubayList = new ArrayList<SimulaFleAubay>();
			int i = 0;
			for (Tcsb03SimAub tcsb03SimAub : tcsb03SimAubList) {
				SimulaFleAubay simulaFleAubay = new SimulaFleAubay();
				//file finale txt
				if (i==0) {
					//first line					
					generaFirstLineFile(simulaFleAubay);
				} else if (tcsb03SimAubList.size()-1 == i) {
					//last line
					generaLastLineFile(simulaFleAubay);
				} else {
					String _1_codiceFto = tcsb03SimAub.getCFrmTec();
					short _2_rezidenza = tcsb03SimAub.getCRes();
					short _3_durata = tcsb03SimAub.getNDur();
					String _4_codAtt = tcsb03SimAub.getCCmp();
					String _5_iRgl = tcsb03SimAub.getTValCmp();
					char _6_segnioImporto = tcsb03SimAub.getTSegCmp();
					char _7_fineFto = tcsb03SimAub.getTFinVal();
					short _8_puma = tcsb03SimAub.getNOrdKeyPum();
					String _9_progressivoFto = tcsb03SimAub.getTPrgRap();
					String _10_progressivoPartita = tcsb03SimAub.getTPrgPta();
					Long _11_codiceUnit�Informativa = tcsb03SimAub.getCUniInf();
					String _12_aDisposizione = tcsb03SimAub.getTDis();
					//file finale txt
					simulaFleAubay.set_1_codiceFto(_1_codiceFto); 
					simulaFleAubay.set_2_rezidenza(_2_rezidenza); 
					simulaFleAubay.set_3_durata(_3_durata);
					simulaFleAubay.set_4_codAtt(_4_codAtt); 
					simulaFleAubay.set_5_iRgl(_5_iRgl);
					simulaFleAubay.set_6_segnioImporto(String.valueOf(_6_segnioImporto));				
					simulaFleAubay.set_7_fineFto(String.valueOf(_7_fineFto));
					simulaFleAubay.set_8_puma(_8_puma);								
					simulaFleAubay.set_9_progressivoFto(_9_progressivoFto);
					simulaFleAubay.set_10_progressivoPartita(_10_progressivoPartita);
					simulaFleAubay.set_11_codiceUnit�Informativa(_11_codiceUnit�Informativa.shortValue());			
					simulaFleAubay.set_12_aDisposizione(_12_aDisposizione);
					
				}
				simulaFleAubayList.add(simulaFleAubay);
				i++;
			}
			
			String pathFile = System.getProperty("csb.application.data.dir") + "\\file_finale.txt";
			UtilFile.simulaFileCreateEntityTcsb03SimAub(pathFile, simulaFleAubayList);
			
		} else {
			Short fagElab = 0;
			Long progressivoFileNonElab = tcsb01RacPreAubService.getMaxProgresivoFile();		
			List<Tcsb01RacPreAub> tcsb01RacPreAubList = tcsb01RacPreAubService.findAllNonElabFile(progressivoFileNonElab, fagElab);
			
			List<Tcsb03SimAub> tcsb03SimAubListDB = new ArrayList<Tcsb03SimAub>();
			List<SimulaFleAubay> simulaFleAubayList = new ArrayList<SimulaFleAubay>();
			Tcsb03SimAub tcsb03SimAubDB_firstLine = new Tcsb03SimAub();
			Tcsb03SimAub tcsb03SimAubDB_LastLine = new Tcsb03SimAub();
			SimulaFleAubay simulaFleAubay_firstLine = new SimulaFleAubay();
			SimulaFleAubay simulaFleAubay_LastLine = new SimulaFleAubay();
			generaFirstLineFile(simulaFleAubay_firstLine);
			generaLastLineFile(simulaFleAubay_LastLine);
			generaFirstLineDB(tcsb03SimAubDB_firstLine, progressivoFileNonElab);
			generaLastLineDB(tcsb03SimAubDB_LastLine, progressivoFileNonElab);
			tcsb03SimAubListDB.add(tcsb03SimAubDB_firstLine);
			simulaFleAubayList.add(simulaFleAubay_firstLine);
			int countFto = 0;
			for (Tcsb01RacPreAub tcsb01RacPreAub : tcsb01RacPreAubList) {
				countFto++;
				Float importoSegnoSim = tcsb01RacPreAub.getIRac();
				String ftoInputSim = tcsb01RacPreAub.getNFto();
				
				Tcsb05Fto tcsb05Fto = new Tcsb05Fto();
				tcsb05Fto.setCFto(ftoInputSim);
				
				String cAttrib = tcsb02RegService.findByCFtoTDesAtt(ftoInputSim, "%DIGIT RESIDENZA%");
				Tcsb04Att tcsb04Att = new Tcsb04Att();
				tcsb04Att.setCAtt(cAttrib);			 
				String iRgl= tcsb02RegService.findByCAtt(tcsb04Att, tcsb05Fto);
				String residenzaSim = iRgl;
				
				String cAttribD = tcsb02RegService.findByCFtoTDesAtt(ftoInputSim, "%INDICATORE DURATA%");
				Tcsb04Att tcsb04AttD = new Tcsb04Att();
				tcsb04AttD.setCAtt(cAttribD); 
			    iRgl= tcsb02RegService.findByCAtt(tcsb04AttD, tcsb05Fto);
				String durataSim = iRgl;
				 
				List<Tcsb02Reg> tcsb02RegARList = tcsb02RegService.findByCFto(tcsb05Fto);
				int i = 0;
				for (Tcsb02Reg tcsb02RegAR : tcsb02RegARList) {
					Tcsb04Att cAttSim = tcsb02RegAR.getCAtt();
					String reglSim = tcsb02RegAR.getIRgl();
					
					String _1_codiceFto = ftoInputSim;
					short _2_rezidenza = Short.valueOf(residenzaSim) ;
					short _3_durata = Short.valueOf(durataSim);
					String _4_codAtt = cAttSim.getCAtt();
					String _5_iRgl = reglSim;
					String _6_segnioImporto = importoSegnoSim < 0 ? "-" : " " ;	
					String _7_fineFto = " ";
					short _8_puma = 1;
					String _9_progressivoFto = String.valueOf(countFto);
					String _10_progressivoPartita ="            ";
					short _11_codiceUnit�Informativa = 210;
					String _12_aDisposizione = "   ";
					if (i == tcsb02RegARList.size()-1) {
						_7_fineFto = "F";
					}
					for (int j = 0; j < 10; j++) {
						_9_progressivoFto =  "0" + _9_progressivoFto;
					}
					for (int k = 0; _5_iRgl.length() < 15; k++) {
						_5_iRgl =  "0" + _5_iRgl;
					}
					//file finale txt
					SimulaFleAubay simulaFleAubay = new SimulaFleAubay();
					simulaFleAubay.set_1_codiceFto(_1_codiceFto); 
					simulaFleAubay.set_2_rezidenza(_2_rezidenza); 
					simulaFleAubay.set_3_durata(_3_durata);
					simulaFleAubay.set_4_codAtt(_4_codAtt); 
					simulaFleAubay.set_5_iRgl(_5_iRgl);
					simulaFleAubay.set_6_segnioImporto(_6_segnioImporto );				
					simulaFleAubay.set_7_fineFto(_7_fineFto);
					simulaFleAubay.set_8_puma(_8_puma);								
					simulaFleAubay.set_9_progressivoFto(_9_progressivoFto);
					simulaFleAubay.set_10_progressivoPartita(_10_progressivoPartita);
					simulaFleAubay.set_11_codiceUnit�Informativa(_11_codiceUnit�Informativa);
					simulaFleAubay.set_12_aDisposizione(_12_aDisposizione);
					simulaFleAubayList.add(simulaFleAubay);
					i++;
					
					Tcsb03SimAub tcsb03SimAubDB = new Tcsb03SimAub();
					tcsb03SimAubDB.setCCmp(_4_codAtt); //Codice Campo
					tcsb03SimAubDB.setCFrmTec(_1_codiceFto); //Identificativo Record di Simulazione
					tcsb03SimAubDB.setCPerRif(null); //Trimestre di riferimento (ciclo)
					tcsb03SimAubDB.setCRes(_2_rezidenza);	//Residenza
					tcsb03SimAubDB.setCUniInf(Long.parseLong(String.valueOf(_11_codiceUnit�Informativa)));		//Codice Unit� Informativa
					tcsb03SimAubDB.setDElaFil(new Date());		//Data elaborazione file
					tcsb03SimAubDB.setDRcdCan(null);		//Data Cancellazione
					tcsb03SimAubDB.setFFilEla(1L);		//Flag se il file e stato elaborato o no
					tcsb03SimAubDB.setFRcdCan('0');		//Flag se il record e stato annullato o no
					tcsb03SimAubDB.setNDur(_3_durata);			//Durata
					tcsb03SimAubDB.setNOrdKeyPum(_8_puma);		//Ordinale Chiave Puma
					tcsb03SimAubDB.setPFl(progressivoFileNonElab);					//Progresivo file input_contabile letto
					tcsb03SimAubDB.setTDis(_12_aDisposizione);				//A disposizione (3 char)
					tcsb03SimAubDB.setTFinVal(_7_fineFto.charAt(0));			//Ultimo Record (F)
					tcsb03SimAubDB.setTFonPvzFil("Locale");	 //Fonte da dove proviene il file
					tcsb03SimAubDB.setTPrgPta(_10_progressivoPartita);			//Progressivo partita
					tcsb03SimAubDB.setTPrgRap(_9_progressivoFto);			//Progressivo Rapporto T_PRG_RAP
					tcsb03SimAubDB.setTSegCmp(_6_segnioImporto.charAt(0));			//Segno Campo
					tcsb03SimAubDB.setTValCmp(_5_iRgl);			//Valore campo
					tcsb03SimAubListDB.add(tcsb03SimAubDB);		
					
				}
			}
			tcsb03SimAubListDB.add(tcsb03SimAubDB_LastLine);
			simulaFleAubayList.add(simulaFleAubay_LastLine);		
			for (Tcsb03SimAub tcsb03SimAub : tcsb03SimAubListDB) {
				getServiceClass().create(tcsb03SimAub);
			}
			
			String pathFile = System.getProperty("csb.application.data.dir") + "\\file_finale.txt";
			UtilFile.simulaFileCreateEntityTcsb03SimAub(pathFile, simulaFleAubayList);
			
			//update Tcsb01RacPreAub
			tcsb01RacPreAubService.updateFelab((short)1, progressivoFileNonElab); 
		}
		
		List<Tcsb03SimAub> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
	
		
		return modelAndView;
	}
	
	@RequestMapping(value="/downloadFile", method=RequestMethod.GET)
	public @ResponseBody void downloadFile(HttpServletResponse response) {
		
		String pathFile = System.getProperty("csb.application.data.dir") + "\\file_finale.txt";
		//download file
        try {
        	File file = new File(pathFile);
    		if (!file.exists()){
                System.out.println("file doesnt exist !!!");
            }
    		InputStream in = new FileInputStream(file);
        	response.setContentType("application/txt");
            response.setHeader("Content-Disposition", "attachment; filename=" + file.getName());
            response.setHeader("Content-Length", String.valueOf(file.length()));
			FileCopyUtils.copy(in, response.getOutputStream());			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	private void generaLastLineDB(Tcsb03SimAub tcsb03SimAubDB_LastLine, Long progressivoFile) {
		String s15 = "";
		for (int i = 0; i < 16; i++) {
			s15 = s15 + "9";			
		}
		tcsb03SimAubDB_LastLine.setTValCmp(s15);
		tcsb03SimAubDB_LastLine.setPFl(progressivoFile);
	}

	private void generaFirstLineDB(Tcsb03SimAub tcsb03SimAubDB_firstLine, Long progressivoFile) {
		String s15 = "";
		for (int i = 0; i < 16; i++) {
			s15 = s15 + "0";			
		}
		tcsb03SimAubDB_firstLine.setTValCmp(s15); 
		tcsb03SimAubDB_firstLine.setPFl(progressivoFile); 
	}

	private void generaLastLineFile(SimulaFleAubay simulaFleAubay_LastLine) {
		String s15 = "";
		for (int i = 0; i < 16; i++) {
			s15 = s15 + "9";			
		}
		String s5 = "";
		for (int i = 0; i < 5; i++) {
			s5 = s5 + "9";			
		}
		SimpleDateFormat st = new SimpleDateFormat("yyyyMMdd");
		String stData = st.format(new Date());
		simulaFleAubay_LastLine.setLastLine(s15+stData+s5);
		
	}

	private void generaFirstLineFile(SimulaFleAubay simulaFleAubay_firstLine) {
		String s15 = "";
		for (int i = 0; i < 16; i++) {
			s15 = s15 + "0";			
		}
		String s5 = "";
		for (int i = 0; i < 5; i++) {
			s5 = s5 + "9";			
		}
		SimpleDateFormat st = new SimpleDateFormat("yyyyMMdd");
		String stData = st.format(new Date());
		simulaFleAubay_firstLine.setFirstLine(s15+stData+s5);
	}

	@Override
	protected AbstractService<Tcsb03SimAub> getServiceClass() {
		return tcsb03SimAubService;
	}
	
	@Override
	protected String getNameAddFormJSP() {
		return nameAddFormJSP;
	}

	@Override
	protected String getNameEditFormJSP() {
		return nameEditFormJSP;
	}

	@Override
	protected String getNameListFormJSP() {
		return nameListFormJSP;
	}

	@Override
	protected Class<Tcsb03SimAub> setEntityName() {	
		entityClass = (Class<Tcsb03SimAub>) entityName.getClass();
		return entityClass;
	}
	
	@Override
	protected String getNameEntity() {
		return nameEntity;
	}

}
