package com.csb.controller;


import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.csb.entity.Tcsb01RacPreAub;
import com.csb.service.AbstractService;
import com.csb.service.Tcsb01RacPreAubService;
import com.csb.util.UtilFile;

@Controller
@RequestMapping(value="/tcsb01RacPreAub")
public class Tcsb01RacPreAubController extends AbstractController<Tcsb01RacPreAub>{
	
	private static final Logger logger = LogManager.getLogger(Tcsb01RacPreAubController.class);

	@Autowired
	private Tcsb01RacPreAubService tcsb01RacPreAubService;
	
	private String nameAddFormJSP =  "Tcsb01RacPreAub/add-form";
	private String nameEditFormJSP = "Tcsb01RacPreAub/edit-form";
	private String nameListFormJSP = "Tcsb01RacPreAub/list-form";
	private String nameEntity ="Tcsb01RacPreAub";
	
	private Tcsb01RacPreAub entityName = new Tcsb01RacPreAub();
	
	
	@RequestMapping(value="/readFile", method=RequestMethod.POST)
	public ModelAndView readFileAndInsert(@RequestParam("file") MultipartFile file, @ModelAttribute Tcsb01RacPreAub entity) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		Long maxProgresivoFile = tcsb01RacPreAubService.getMaxProgresivoFile();
		if (maxProgresivoFile == null) {
			maxProgresivoFile = (long) 1;
		}		
		BufferedReader reader = null;
		try {
			InputStream in = file.getInputStream();
			reader = new BufferedReader(new InputStreamReader(in));
		} catch (IOException e) {
			e.printStackTrace();
		}
		ArrayList<Tcsb01RacPreAub> tcsb01RacPreAubList = UtilFile.readFileCreateEntityTcsb01RacPreAub(reader);
		for (Tcsb01RacPreAub tcsb01RacPreAub : tcsb01RacPreAubList) {
			tcsb01RacPreAub.setPFl(maxProgresivoFile+1);
			getServiceClass().create(tcsb01RacPreAub);
		}
		List<Tcsb01RacPreAub> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	/*
	@RequestMapping(value = "/readFile", method = RequestMethod.POST)
	public ModelAndView submit(@RequestParam("file") MultipartFile file) {
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		Long maxProgresivoFile = tcsb01RacPreAubService.getMaxProgresivoFile();
		if (maxProgresivoFile == null) {
			maxProgresivoFile = (long) 1;
		}
		BufferedReader reader = null;
		try {
			InputStream in = file.getInputStream();
			reader = new BufferedReader(new InputStreamReader(in));
		} catch (IOException e) {
			e.printStackTrace();
		}
		ArrayList<Tcsb01RacPreAub> tcsb01RacPreAubList = UtilFile.readFileCreateEntityTcsb01RacPreAub(reader);
		for (Tcsb01RacPreAub tcsb01RacPreAub : tcsb01RacPreAubList) {
			tcsb01RacPreAub.setPFl(maxProgresivoFile); 
			getServiceClass().create(tcsb01RacPreAub);
		}
		List<Tcsb01RacPreAub> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	*/

	@Override
	protected AbstractService<Tcsb01RacPreAub> getServiceClass() {
		return tcsb01RacPreAubService;
	}
	
	@Override
	protected String getNameAddFormJSP() {
		return nameAddFormJSP;
	}

	@Override
	protected String getNameEditFormJSP() {
		return nameEditFormJSP;
	}

	@Override
	protected String getNameListFormJSP() {
		return nameListFormJSP;
	}

	@Override
	protected Class<Tcsb01RacPreAub> setEntityName() {	
		entityClass = (Class<Tcsb01RacPreAub>) entityName.getClass();
		return entityClass;
	}

	@Override
	protected String getNameEntity() {
		return nameEntity;
	}
}
