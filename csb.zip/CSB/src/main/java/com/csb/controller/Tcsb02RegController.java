package com.csb.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.csb.entity.Tcsb01RacPreAub;
import com.csb.entity.Tcsb02Reg;
import com.csb.entity.Tcsb02Reg;
import com.csb.service.AbstractService;
import com.csb.service.Tcsb02RegService;
import com.csb.util.EntityString;
import com.csb.util.UtilFile;

@Controller
@RequestMapping(value="/tcsb02Reg")
public class Tcsb02RegController extends AbstractController<Tcsb02Reg>{
	
	private static final Logger logger = LogManager.getLogger(Tcsb02RegController.class);

	@Autowired
	private Tcsb02RegService tcsb02RegService;
	
	private String nameAddFormJSP = "Tcsb02Reg/add-form";
	private String nameEditFormJSP = "Tcsb02Reg/edit-form";
	private String nameListFormJSP = "Tcsb02Reg/list-form";
	private String nameEntity ="Tcsb02Reg";
	
	private Tcsb02Reg entityName = new Tcsb02Reg();
	
	@RequestMapping(value="/readFile", method=RequestMethod.POST)
	public ModelAndView readFileAndInsert(@RequestParam("file") MultipartFile file, @ModelAttribute Tcsb02Reg entity) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());	
		BufferedReader reader = null;
		try {
			InputStream in = file.getInputStream();
			reader = new BufferedReader(new InputStreamReader(in));
		} catch (IOException e) {
			e.printStackTrace();
		}
		ArrayList<Tcsb02Reg> tcsb02RegList = UtilFile.readFileCreateEntityTcsb02Reg(reader);
		for (Tcsb02Reg tcsb02Reg : tcsb02RegList) { 
			getServiceClass().create(tcsb02Reg);
		}
		List<Tcsb02Reg> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}

	@Override
	protected AbstractService<Tcsb02Reg> getServiceClass() {
		return tcsb02RegService;
	}

	@Override
	protected String getNameAddFormJSP() {
		return nameAddFormJSP;
	}

	@Override
	protected String getNameEditFormJSP() {
		return nameEditFormJSP;
	}

	@Override
	protected String getNameListFormJSP() {
		return nameListFormJSP;
	}

	@Override
	protected Class<Tcsb02Reg> setEntityName() {	
		entityClass = (Class<Tcsb02Reg>) entityName.getClass();
		return entityClass;
	}

	@Override
	protected String getNameEntity() {
		return nameEntity;
	}
}
