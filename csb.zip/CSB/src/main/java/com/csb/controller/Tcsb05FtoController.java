package com.csb.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.csb.entity.Tcsb04Att;
import com.csb.entity.Tcsb05Fto;
import com.csb.entity.Tcsb05Fto;
import com.csb.service.AbstractService;
import com.csb.service.Tcsb05FtoService;
import com.csb.util.EntityString;
import com.csb.util.UtilFile;

@Controller
@RequestMapping(value="/tcsb05Fto")
public class Tcsb05FtoController extends AbstractController<Tcsb05Fto>{
	
	private static final Logger logger = LogManager.getLogger(Tcsb05FtoController.class);

	@Autowired
	private Tcsb05FtoService tcsb05FtoService;
	
	private String nameAddFormJSP = "Tcsb05Fto/add-form";
	private String nameEditFormJSP = "Tcsb05Fto/edit-form";
	private String nameListFormJSP = "Tcsb05Fto/list-form";
	private String nameEntity ="Tcsb05Fto";
	
	private Tcsb05Fto entityName = new Tcsb05Fto();
	
	@RequestMapping(value="/readFile", method=RequestMethod.POST)
	public ModelAndView readFileAndInsert(@RequestParam("file") MultipartFile file, @ModelAttribute Tcsb05Fto entity) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		BufferedReader reader = null;
		try {
			InputStream in = file.getInputStream();
			reader = new BufferedReader(new InputStreamReader(in));
		} catch (IOException e) {
			e.printStackTrace();
		}
		ArrayList<EntityString> entityStringList = UtilFile.readFileGeneric(reader);
		for (EntityString entityString : entityStringList) {
			Tcsb05Fto tcsb05Fto = new Tcsb05Fto();
			tcsb05Fto.setCFto(entityString.getValue1());
			tcsb05Fto.setTDesFto(entityString.getValue2()); 
			getServiceClass().create(tcsb05Fto);
		}
		List<Tcsb05Fto> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/editTcsb05Fto/{id}", method=RequestMethod.GET)
	public ModelAndView editTcsb05FtoPage(@PathVariable String id) {
		ModelAndView modelAndView = new ModelAndView(getNameEditFormJSP());
		Tcsb05Fto entity = getServiceClass().find(id);
		setEntityName();
		modelAndView.addObject(getNameEntity(), entity);
		return modelAndView;
	}
	
	@RequestMapping(value="/editTcsb05Fto/{id}", method=RequestMethod.POST)
	public ModelAndView edditingTcsb05Fto(@ModelAttribute Tcsb05Fto entity, @PathVariable String id) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		entity.setCFto(id);
		getServiceClass().edit(entity);
		setEntityName();
		String message = entityClass.getName() + " was successfully edited.";
		
		List<Tcsb05Fto> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/deleteTcsb05Fto/{id}", method=RequestMethod.GET)
	public ModelAndView deleteTcsb05Fto(@PathVariable String id) {
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		getServiceClass().remove(id);
		setEntityName();
		String message = entityClass.getName() + " was successfully deleted.";
		
		List<Tcsb05Fto> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}

	@Override
	protected AbstractService<Tcsb05Fto> getServiceClass() {
		return tcsb05FtoService;
	}

	@Override
	protected String getNameAddFormJSP() {
		return nameAddFormJSP;
	}

	@Override
	protected String getNameEditFormJSP() {
		return nameEditFormJSP;
	}

	@Override
	protected String getNameListFormJSP() {
		return nameListFormJSP;
	}

	@Override
	protected Class<Tcsb05Fto> setEntityName() {	
		entityClass = (Class<Tcsb05Fto>) entityName.getClass();
		return entityClass;
	}
	
	@Override
	protected String getNameEntity() {
		return nameEntity;
	}

}
