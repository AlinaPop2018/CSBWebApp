package com.csb.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.csb.entity.Tcsb03SimAub;
import com.csb.entity.Tcsb04Att;
import com.csb.entity.Tcsb04Att;
import com.csb.service.AbstractService;
import com.csb.service.Tcsb04AttService;
import com.csb.util.EntityString;
import com.csb.util.UtilFile;

@Controller
@RequestMapping(value="/tcsb04Att")
public class Tcsb04AttController extends AbstractController<Tcsb04Att>{
	
	private static final Logger logger = LogManager.getLogger(Tcsb04AttController.class);

	@Autowired
	private Tcsb04AttService Tcsb04AttService;
	
	private String nameAddFormJSP = "Tcsb04Att/add-form";
	private String nameEditFormJSP = "Tcsb04Att/edit-form";
	private String nameListFormJSP = "Tcsb04Att/list-form";
	private String nameEntity ="Tcsb04Att";
	
	private Tcsb04Att entityName = new Tcsb04Att();
	
	@RequestMapping(value="/readFile", method=RequestMethod.POST)
	public ModelAndView readFileAndInsert(@RequestParam("file") MultipartFile file, @ModelAttribute Tcsb04Att entity) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		BufferedReader reader = null;
		try {
			InputStream in = file.getInputStream();
			reader = new BufferedReader(new InputStreamReader(in));
		} catch (IOException e) {
			e.printStackTrace();
		}ArrayList<EntityString> entityStringList = UtilFile.readFileGeneric(reader);
		for (EntityString entityString : entityStringList) {
			Tcsb04Att tcsb04Att = new Tcsb04Att();
			tcsb04Att.setCAtt(entityString.getValue1());
			tcsb04Att.setTDesAtt(entityString.getValue2()); 
			getServiceClass().create(tcsb04Att);
		}
		List<Tcsb04Att> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/editTcsb04Att/{id}", method=RequestMethod.GET)
	public ModelAndView editTcsb04AttPage(@PathVariable String id) {
		ModelAndView modelAndView = new ModelAndView(getNameEditFormJSP());
		Tcsb04Att entity = getServiceClass().find(id);
		setEntityName();
		modelAndView.addObject(getNameEntity(), entity);
		return modelAndView;
	}
	
	@RequestMapping(value="/editTcsb04Att/{id}", method=RequestMethod.POST)
	public ModelAndView edditingTcsb04Att(@ModelAttribute Tcsb04Att entity, @PathVariable String id) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		entity.setCAtt(id); 
		getServiceClass().edit(entity);
		setEntityName();
		String message = entityClass.getName() + " was successfully edited.";
		
		List<Tcsb04Att> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/deleteTcsb04Att/{id}", method=RequestMethod.GET)
	public ModelAndView deleteTcsb04Att(@PathVariable String id) {
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		getServiceClass().remove(id);
		setEntityName();
		String message = entityClass.getName() + " was successfully deleted.";
		
		List<Tcsb04Att> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}

	@Override
	protected AbstractService<Tcsb04Att> getServiceClass() {
		return Tcsb04AttService;
	}
	
	@Override
	protected String getNameAddFormJSP() {
		return nameAddFormJSP;
	}

	@Override
	protected String getNameEditFormJSP() {
		return nameEditFormJSP;
	}

	@Override
	protected String getNameListFormJSP() {
		return nameListFormJSP;
	}

	@Override
	protected Class<Tcsb04Att> setEntityName() {	
		entityClass = (Class<Tcsb04Att>) entityName.getClass();
		return entityClass;
	}
	
	@Override
	protected String getNameEntity() {
		return nameEntity;
	}

}
