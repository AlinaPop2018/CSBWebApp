package com.csb.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.csb.service.AbstractService;

public abstract class AbstractController<T> {
	
	private static final Logger logger = LogManager.getLogger(AbstractController.class);
	
	protected abstract AbstractService<T> getServiceClass();
	
	Class<T> entityClass;
	
	protected abstract String getNameAddFormJSP();
	protected abstract String getNameEditFormJSP();
	protected abstract String getNameListFormJSP();
	protected abstract String getNameEntity();
	
	protected abstract Class<T> setEntityName();
	
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public ModelAndView addTeamPage() {
		ModelAndView modelAndView = new ModelAndView(getNameAddFormJSP());
		try {
			setEntityName();
			modelAndView.addObject(getNameEntity(), entityClass.newInstance());
		} catch (InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		return modelAndView;
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ModelAndView addingTeam(@ModelAttribute T entity) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		getServiceClass().create(entity);
		setEntityName();
		String message = entityClass.getName() + " was successfully added.";
		
		List<T> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/list")
	public ModelAndView listOfTeams() {
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		
		List<T> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.GET)
	public ModelAndView editTeamPage(@PathVariable Long id) {
		ModelAndView modelAndView = new ModelAndView(getNameEditFormJSP());
		T entity = getServiceClass().find(id);
		setEntityName();
		modelAndView.addObject(getNameEntity(), entity);
		return modelAndView;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.POST)
	public ModelAndView edditingTeam(@ModelAttribute T entity, @PathVariable Long id) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());

		getServiceClass().edit(entity);
		setEntityName();
		String message = entityClass.getName() + " was successfully edited.";
		
		List<T> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.GET)
	public ModelAndView deleteTeam(@PathVariable Long id) {
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		getServiceClass().remove(id);
		setEntityName();
		String message = entityClass.getName() + " was successfully deleted.";
		
		List<T> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}

}
