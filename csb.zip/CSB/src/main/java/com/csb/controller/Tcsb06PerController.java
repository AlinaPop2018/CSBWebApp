package com.csb.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.csb.entity.Tcsb01RacPreAub;
import com.csb.entity.Tcsb05Fto;
import com.csb.entity.Tcsb06Per;
import com.csb.service.AbstractService;
import com.csb.service.Tcsb06PerService;
import com.csb.util.EntityString;
import com.csb.util.UtilFile;

@Controller
@RequestMapping(value="/tcsb06Per")
public class Tcsb06PerController extends AbstractController<Tcsb06Per>{
	
	private static final Logger logger = LogManager.getLogger(Tcsb06PerController.class);

	@Autowired
	private Tcsb06PerService tcsb06PerService;
	
	private String nameAddFormJSP = "Tcsb06Per/add-form";
	private String nameEditFormJSP = "Tcsb06Per/edit-form";
	private String nameListFormJSP = "Tcsb06Per/list-form";
	private String nameEntity ="Tcsb06Per";
	
	private Tcsb06Per entityName = new Tcsb06Per();
	
	@RequestMapping(value="/readFile", method=RequestMethod.POST)
	public ModelAndView readFileAndInsert(@RequestParam("file") MultipartFile file, @ModelAttribute Tcsb06Per entity) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		BufferedReader reader = null;
		try {
			InputStream in = file.getInputStream();
			reader = new BufferedReader(new InputStreamReader(in));
		} catch (IOException e) {
			e.printStackTrace();
		}
		ArrayList<EntityString> entityStringList = UtilFile.readFileGeneric(reader);
		for (EntityString entityString : entityStringList) {
			Tcsb06Per tcsb06Per = new Tcsb06Per();
			tcsb06Per.setCPer(entityString.getValue1());
			tcsb06Per.setTDesPer(entityString.getValue2()); 
			getServiceClass().create(tcsb06Per);
		}
		List<Tcsb06Per> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/editTcsb06Per/{id}", method=RequestMethod.GET)
	public ModelAndView editTcsb06PerPage(@PathVariable String id) {
		ModelAndView modelAndView = new ModelAndView(getNameEditFormJSP());
		Tcsb06Per entity = getServiceClass().find(id);
		setEntityName();
		modelAndView.addObject(getNameEntity(), entity);
		return modelAndView;
	}
	
	@RequestMapping(value="/editTcsb06Per/{id}", method=RequestMethod.POST)
	public ModelAndView edditingTcsb06Per(@ModelAttribute Tcsb06Per entity, @PathVariable String id) {
		
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		entity.setCPer(id);
		getServiceClass().edit(entity);
		setEntityName();
		String message = entityClass.getName() + " was successfully edited.";
		
		List<Tcsb06Per> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/deleteTcsb06Per/{id}", method=RequestMethod.GET)
	public ModelAndView deleteTcsb06Per(@PathVariable String id) {
		ModelAndView modelAndView = new ModelAndView(getNameListFormJSP());
		getServiceClass().remove(id);
		setEntityName();
		String message = entityClass.getName() + " was successfully deleted.";
		
		List<Tcsb06Per> entityList = getServiceClass().findAll();
		modelAndView.addObject(getNameEntity(), entityList);
		
		return modelAndView;
	}

	@Override
	protected AbstractService<Tcsb06Per> getServiceClass() {
		return tcsb06PerService;
	}

	@Override
	protected String getNameAddFormJSP() {
		return nameAddFormJSP;
	}

	@Override
	protected String getNameEditFormJSP() {
		return nameEditFormJSP;
	}

	@Override
	protected String getNameListFormJSP() {
		return nameListFormJSP;
	}

	@Override
	protected Class<Tcsb06Per> setEntityName() {	
		entityClass = (Class<Tcsb06Per>) entityName.getClass();
		return entityClass;
	}
	
	@Override
	protected String getNameEntity() {
		return nameEntity;
	}

}
