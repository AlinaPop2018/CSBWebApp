package com.csb.util;

public class SimulaFleAubay {

	public SimulaFleAubay() {
		
	}
	
	private String firstLine;
	
	private String lastLine;
	
	/*
	 * per ogni codice_fto, letto dal file di input
	 */
	private String _1_codiceFto;
	

	
	/*
	 * cod_attributo = DIGIT RESIDENZA
	 * si ripete in tutto il file
	 */
	private short _2_rezidenza;
	
	/*
	 * cod_attributo = INDICATORE DURATA
	 * si ripete in tutto il file
	 */
	private short _3_durata;
	
	/*
	 * per il primo record prevedere 5 spazi
	 * Dalla tabella "regole di base", tutti i : Codice attributo, per un FTO
	 */
	private String _4_codAtt;
	
	/*
	 * al centesimo - moltiplicare input contabile per 100 - aggiungere 0 ad inizio fino a raggiungimento 15 chars
	 * es: 000000020170701
	 */
	private String _5_iRgl;
	
	/*
	 * Valorizzato a Spazio per positivo, con - se negativo
	 */
	private String _6_segnioImporto;
	
	/*
	 * se ultimo valore per FTO metti F, altrimenti spazio
	 */
	private String _7_fineFto;
	
	/*
	 * valorizzare sempre con 1
	 */
	private short _8_puma;
	
	/*
	 * quando cambia FTO, incrementa
	 */
	private String _9_progressivoFto;
	
	/*
	 * 12 spazi
	 */
	private String _10_progressivoPartita;
	
	/*
	 * sempre 210
	 */
	private short _11_codiceUnit�Informativa;
	
	/*
	 * valorizzare sempre con 3 spazi
	 */
	private String _12_aDisposizione;
	
	public String getFirstLine() {
		return firstLine;
	}

	public void setFirstLine(String firstLine) {
		this.firstLine = firstLine;
	}

	public String getLastLine() {
		return lastLine;
	}

	public void setLastLine(String lastLine) {
		this.lastLine = lastLine;
	}

	public String get_1_codiceFto() {
		return _1_codiceFto;
	}

	public void set_1_codiceFto(String _1_codiceFto) {
		this._1_codiceFto = _1_codiceFto;
	}

	public short get_2_rezidenza() {
		return _2_rezidenza;
	}

	public void set_2_rezidenza(short _2_rezidenza) {
		this._2_rezidenza = _2_rezidenza;
	}

	public short get_3_durata() {
		return _3_durata;
	}

	public void set_3_durata(short _3_durata) {
		this._3_durata = _3_durata;
	}

	public String get_4_codAtt() {
		return _4_codAtt;
	}

	public void set_4_codAtt(String _4_codAtt) {
		this._4_codAtt = _4_codAtt;
	}

	public String get_5_iRgl() {
		return _5_iRgl;
	}

	public void set_5_iRgl(String _5_iRgl) {
		this._5_iRgl = _5_iRgl;
	}

	public String get_6_segnioImporto() {
		return _6_segnioImporto;
	}

	public void set_6_segnioImporto(String _6_segnioImporto) {
		this._6_segnioImporto = _6_segnioImporto;
	}

	public String get_7_fineFto() {
		return _7_fineFto;
	}

	public void set_7_fineFto(String _7_fineFto) {
		this._7_fineFto = _7_fineFto;
	}

	public short get_8_puma() {
		return _8_puma;
	}

	public void set_8_puma(short _8_puma) {
		this._8_puma = _8_puma;
	}

	public String get_9_progressivoFto() {
		return _9_progressivoFto;
	}

	public void set_9_progressivoFto(String _9_progressivoFto) {
		this._9_progressivoFto = _9_progressivoFto;
	}

	public String get_10_progressivoPartita() {
		return _10_progressivoPartita;
	}

	public void set_10_progressivoPartita(String _10_progressivoPartita) {
		this._10_progressivoPartita = _10_progressivoPartita;
	}

	public short get_11_codiceUnit�Informativa() {
		return _11_codiceUnit�Informativa;
	}

	public void set_11_codiceUnit�Informativa(short _11_codiceUnit�Informativa) {
		this._11_codiceUnit�Informativa = _11_codiceUnit�Informativa;
	}

	public String get_12_aDisposizione() {
		return _12_aDisposizione;
	}

	public void set_12_aDisposizione(String _12_aDisposizione) {
		this._12_aDisposizione = _12_aDisposizione;
	}
	
	
	public String toString() {
        return _1_codiceFto + _2_rezidenza + _3_durata +_4_codAtt + _5_iRgl +
        		_6_segnioImporto + _7_fineFto + _8_puma + _9_progressivoFto +
        		_10_progressivoPartita + _11_codiceUnit�Informativa + _12_aDisposizione;
    }

}
