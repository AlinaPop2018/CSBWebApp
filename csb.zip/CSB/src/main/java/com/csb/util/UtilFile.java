package com.csb.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import com.csb.entity.Tcsb01RacPreAub;
import com.csb.entity.Tcsb02Reg;
import com.csb.entity.Tcsb03SimAub;
import com.csb.entity.Tcsb04Att;
import com.csb.entity.Tcsb05Fto;

public class UtilFile {

	public UtilFile() {
	}
	
	public static Properties fromFile(String fileName) throws IOException {
		InputStream is = new FileInputStream(fileName);
		Properties properties = new Properties();
		properties.load(is);
		is.close();
		return properties;
	}

	public static ArrayList<Tcsb01RacPreAub> readFileCreateEntityTcsb01RacPreAub(BufferedReader br) {
		ArrayList<Tcsb01RacPreAub> tcsb01RacPreAubList = new ArrayList<Tcsb01RacPreAub>();
		if (br != null) {
			try {
				String st;
				int i = 0;
				while ((st = br.readLine()) != null) {
					if (i == 0) {
						// non lego la prima riga
					} else {
						Tcsb01RacPreAub entity = new Tcsb01RacPreAub();
						String[] parts = st.split(",");
						entity.setCTipCnt(parts[3]); // tipologia conto - SP
						entity.setDLetFil(new Date());
						entity.setFCan((short) 0);// Record cancellato o no
						entity.setFEla((short) 0); // Flag se il record e' stato elaborato o no
						entity.setIRac(Float.valueOf(parts[4])); // Importo : -168469.00
						entity.setNCnt(parts[0]); // numero conto - AUTO0022101010012A
						String fto = parts[2].replace(".", "");					
						entity.setNFto(fto); // numero del FTO - 01223.01
						entity.setTDesCnt(parts[1]); // descrizione del conto - F.do Amm.to imm.:Costi di impianto e
														// ampliamento
						entity.setTFonPvzFil(getServerName()); // Fonte da dove proviene il file
						tcsb01RacPreAubList.add(entity);
						System.out.println(st);
					}
					i++;
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
		

		return tcsb01RacPreAubList;

	}

	public static ArrayList<EntityString> readFileGeneric(BufferedReader br) {
		ArrayList<EntityString> stringList = new ArrayList<EntityString>();
		if (br != null) {
			try {
				String st;
				int i = 0;
				while ((st = br.readLine()) != null) {
					String[] parts = st.split(",");
					EntityString entity = new EntityString();
					entity.setValue1(parts[0]);
					entity.setValue2(parts[1]);
					stringList.add(entity);
					System.out.println(st);
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return stringList;

	}

		
	public static ArrayList<Tcsb02Reg> readFileCreateEntityTcsb02Reg(BufferedReader br) {
		ArrayList<Tcsb02Reg> Tcsb02RegList = new ArrayList<Tcsb02Reg>();
		if (br != null) {			
			try {
				String st;
				int i = 0;
				while ((st = br.readLine()) != null) {			
					System.out.println(st);
					if (i == 0) {
						// non lego la prima riga
					} else {
						Tcsb02Reg entity = new Tcsb02Reg();
						String[] parts = st.split(";");
						Tcsb04Att tcsb04Att = new Tcsb04Att();
						String codAtt = parts[0]; // Codice attributo : 00004
						String desAtt = parts[1]; // Descrizione attributo : DIGIT RESIDENZA
						tcsb04Att.setCAtt(codAtt); 
						entity.setCAtt(tcsb04Att); 
						Tcsb05Fto tcsb05Fto = new Tcsb05Fto();
						String codFto = parts[2]; // Codice FTO : 111532
						String descFTO = parts[3]; // Descrizione FTO : CONTI CORRENTI ATTIVI ISTITUZIONI CREDITIZIE
						tcsb05Fto.setCFto(codFto); 
						entity.setCFto(tcsb05Fto);
						String dateFl = parts[4]; // Data inizio validita' : 20180601
						Date date;
						try {
							date = new SimpleDateFormat("yyyyMMdd").parse(dateFl);
							entity.setDIniVal(date);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}					 
						String contocoge = parts[5]; // contocoge		
						entity.setTCntCog(contocoge); 
						entity.setNPrgRgl(Long.valueOf(parts[6])); // Progressivo : 1
						entity.setIRgl(parts[7]); // campo valore (stringa) : 9999999999999
						//entity.setTNot(parts[8]); // Note
						Tcsb02RegList.add(entity);
					}
					i++;
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
		

		return Tcsb02RegList;

	}
	
	public static void writeFile(String pathFile) {
		PrintWriter writer;
		try {
			writer = new PrintWriter("the-file-name.txt", "UTF-8");
			writer.println("The first line");
			writer.println("The second line");
			writer.close();
		} catch (FileNotFoundException | UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		List<String> lines = Arrays.asList("The first line", "The second line");
		Path file = Paths.get("the-file-name.txt");
		try {
			Files.write(file, lines, Charset.forName("UTF-8"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Files.write(file, lines, Charset.forName("UTF-8"), StandardOpenOption.APPEND);
	}

	public static void simulaFileCreateEntityTcsb03SimAub(String pathFile, List<SimulaFleAubay> simulaFleAubayList) {
		
		PrintWriter writer;
		try {
			writer = new PrintWriter(pathFile, "UTF-8");
			int i = 0;
			for (SimulaFleAubay simulaFleAubay : simulaFleAubayList) {
				if (i==0) {
					writer.println(simulaFleAubayList.get(0).getFirstLine());
				} else if (simulaFleAubayList.size()-1 == i) {
					writer.println(simulaFleAubayList.get(simulaFleAubayList.size()-1).getLastLine());
				} else {
					writer.println(simulaFleAubay.toString());
				}
				i++;
			}			
			writer.close();
		} catch (FileNotFoundException | UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public static String getServerName() throws Exception{
        String serverName = "";
        InetAddress inAdd = InetAddress.getLocalHost();
        serverName = inAdd.getHostName();

        return serverName;
	}
}
