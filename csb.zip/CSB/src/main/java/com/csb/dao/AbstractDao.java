/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csb.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author utente
 */
public abstract class AbstractDao<T> {

    
    private Class<T> entityClass;
    
    @Autowired
    protected abstract Session getCurrentSessionAbstr();

    public AbstractDao(Class<T> entityClass) {
        this.entityClass = entityClass;
    }

	public void create(T entity) {
    	getCurrentSessionAbstr().save(entity);
    }

    public void edit(T entity) {
    	getCurrentSessionAbstr().update(entity);
    }
    
    public T find(Object id) {
		T entity = (T) getCurrentSessionAbstr().get(entityClass, (Serializable) id);
		return entity;
	}

    public void remove(Object id) {
    	T entity = find(id);
		if (entity != null)
			((Session) getCurrentSessionAbstr()).delete(entity);
    }

    public List<T> findAll() {
        return getCurrentSessionAbstr().createQuery("from " + entityClass.getName()).list();
    }

    public List<T> findRange(int[] range) {
        Query query = ((Session) getCurrentSessionAbstr()).createQuery("from " + entityClass.getName());
        query.setMaxResults(range[1] - range[0] + 1);
        query.setFirstResult(range[0]);
        return query.list();
    }

    public int count() {
    	int count = ((Long) getCurrentSessionAbstr().createQuery("select count(*) from "  + entityClass.getName()).uniqueResult()).intValue();
        return count;
    }
    
}
