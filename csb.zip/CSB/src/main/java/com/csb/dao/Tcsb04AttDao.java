package com.csb.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.csb.entity.Tcsb04Att;

@Repository
public class Tcsb04AttDao extends AbstractDao<Tcsb04Att> {
	
	@Autowired
	private SessionFactory sessionFactory;
	 
	public Tcsb04AttDao() {
		super(Tcsb04Att.class);
	}

	@Override
	protected Session getCurrentSessionAbstr() {
		return sessionFactory.getCurrentSession();
	}

}
