package com.csb.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.csb.entity.Tcsb02Reg;
import com.csb.entity.Tcsb03SimAub;

@Repository
public class Tcsb03SimAubDao extends AbstractDao<Tcsb03SimAub> {

	@Autowired
	private SessionFactory sessionFactory;
	 
	public Tcsb03SimAubDao() {
		super(Tcsb03SimAub.class);
	}

	@Override
	protected Session getCurrentSessionAbstr() {
		return sessionFactory.getCurrentSession();
	}

	public List<Tcsb03SimAub> findAllElabFile(Long progressivoFile) {
		Query query =  getCurrentSessionAbstr().getNamedQuery("Tcsb03SimAub.findByPFl").setLong("pFl", progressivoFile);
		List<Tcsb03SimAub> tcsb03SimAubList = query.list();
		return tcsb03SimAubList;
	}
}
