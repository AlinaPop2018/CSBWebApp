package com.csb.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.csb.entity.Tcsb01RacPreAub;

@Repository
public class Tcsb01RacPreAubDao extends AbstractDao<Tcsb01RacPreAub>{
	
	@Autowired
	private SessionFactory sessionFactory;
	 
	public Tcsb01RacPreAubDao() {
		super(Tcsb01RacPreAub.class);
	}

	@Override
	protected Session getCurrentSessionAbstr() {
		return sessionFactory.getCurrentSession();
	}
	
	public Long maxProgresivoFile() {
		Long count = ((Long) getCurrentSessionAbstr().getNamedQuery("Tcsb01RacPreAub.maxProgresivoFile").uniqueResult());
		return count;
	}
	
	public Long maxProgresivoElabFile(short fElab) {
		Long count = ((Long) getCurrentSessionAbstr().getNamedQuery("Tcsb01RacPreAub.maxProgresivoElabFile").setShort("fEla", fElab).uniqueResult());
		return count;
	}
	
	public List<Tcsb01RacPreAub> findAllNonElabFile(Long progressivoFile, Short fagElab) {
		Query query = getCurrentSessionAbstr().getNamedQuery("Tcsb01RacPreAub.findAllNonElabFile");
		query.setLong("pFl", progressivoFile);
		query.setShort("fEla", fagElab);
		return query.list();
	}
	
	public void updateFelab(Short fElab, Long pFl) {
		String queryString = "update {h-schema}TCSB01_RAC_PRE_AUB \r\n" + 
				"set F_ELA = ? \r\n" + 
				"where P_FL = ?";
		Query query = getCurrentSessionAbstr().createSQLQuery(queryString);
		query.setShort(1, fElab);
		query.setLong(2, pFl);
		int res = query.executeUpdate();
	}
	
	
	public List findAllNonElab(Short fElab) {
		Query query = getCurrentSessionAbstr().getNamedQuery("Tcsb01RacPreAub.findAllNonElab").setShort("fEla", fElab);		
		return query.list();
	}
}
