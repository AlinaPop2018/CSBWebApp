package com.csb.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.csb.entity.Tcsb05Fto;

@Repository
public class Tcsb05FtoDao extends AbstractDao<Tcsb05Fto> {
	
	@Autowired
	private SessionFactory sessionFactory;
	 
	public Tcsb05FtoDao() {
		super(Tcsb05Fto.class);
	}

	@Override
	protected Session getCurrentSessionAbstr() {
		return sessionFactory.getCurrentSession();
	}

}
