package com.csb.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.csb.entity.Tcsb06Per;

@Repository
public class Tcsb06PerDao extends AbstractDao<Tcsb06Per> {
	
	@Autowired
	private SessionFactory sessionFactory;
	 
	public Tcsb06PerDao() {
		super(Tcsb06Per.class);
	}

	@Override
	protected Session getCurrentSessionAbstr() {
		return sessionFactory.getCurrentSession();
	}

}
