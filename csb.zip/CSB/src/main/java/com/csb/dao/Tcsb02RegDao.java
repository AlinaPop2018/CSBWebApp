package com.csb.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.csb.entity.Tcsb02Reg;
import com.csb.entity.Tcsb04Att;
import com.csb.entity.Tcsb05Fto;

@Repository
public class Tcsb02RegDao extends AbstractDao<Tcsb02Reg>{

	@Autowired
	private SessionFactory sessionFactory;
	 
	public Tcsb02RegDao() {
		super(Tcsb02Reg.class);
	}

	@Override
	protected Session getCurrentSessionAbstr() {
		return sessionFactory.getCurrentSession();
	}
	
	public String findByCAtt(Tcsb04Att tcsb04Att, Tcsb05Fto tcsb05Fto) {
		String iRgl = (String) getCurrentSessionAbstr().getNamedQuery("Tcsb02Reg.findByCAtt").setEntity("cAtt", tcsb04Att).setEntity("cFto", tcsb05Fto).uniqueResult();
		return iRgl;
	}
	
	public List<Tcsb02Reg> findByCFto(Tcsb05Fto tcsb05Fto) {
		Query query =  getCurrentSessionAbstr().getNamedQuery("Tcsb02Reg.findByCFto").setEntity("cFto", tcsb05Fto);
		List<Tcsb02Reg> tcsb02RegList = query.list();
		return tcsb02RegList;
	}
	
	public String findByCFtoTDesAtt(String cFto, String tDesAtt) {
		String queryString = "select reg.C_ATT \r\n" + 
				"from {h-schema}TCSB02_REG reg , {h-schema}TCSB04_ATT att\r\n" + 
				"where reg.C_FTO = ? \r\n" + 
				"and reg.C_ATT = att.C_ATT \r\n" + 
				"and att.T_DES_ATT like ? ";
		Query query = getCurrentSessionAbstr().createSQLQuery(queryString);
		query.setString(1, cFto);
		query.setString(2, tDesAtt);
		String cAtt = (String) query.uniqueResult();
		return cAtt;
	}

}
