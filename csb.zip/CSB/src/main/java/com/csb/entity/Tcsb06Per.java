/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csb.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author utente
 */
@Entity
@Table(name = "TCSB06_PER")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tcsb06Per.findAll", query = "SELECT t FROM Tcsb06Per t")
    , @NamedQuery(name = "Tcsb06Per.findByCPer", query = "SELECT t FROM Tcsb06Per t WHERE t.cPer = :cPer")
    , @NamedQuery(name = "Tcsb06Per.findByTDesPer", query = "SELECT t FROM Tcsb06Per t WHERE t.tDesPer = :tDesPer")})
public class Tcsb06Per implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "C_PER")
    private String cPer;
    @Size(max = 255)
    @Column(name = "T_DES_PER")
    private String tDesPer;
    @OneToMany(mappedBy = "cPerRif")
    private Collection<Tcsb03SimAub> tcsb03SimAubCollection;

    public Tcsb06Per() {
    }

    public Tcsb06Per(String cPer) {
        this.cPer = cPer;
    }

    public String getCPer() {
        return cPer;
    }

    public void setCPer(String cPer) {
        this.cPer = cPer;
    }

    public String getTDesPer() {
        return tDesPer;
    }

    public void setTDesPer(String tDesPer) {
        this.tDesPer = tDesPer;
    }

    @XmlTransient
    public Collection<Tcsb03SimAub> getTcsb03SimAubCollection() {
        return tcsb03SimAubCollection;
    }

    public void setTcsb03SimAubCollection(Collection<Tcsb03SimAub> tcsb03SimAubCollection) {
        this.tcsb03SimAubCollection = tcsb03SimAubCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cPer != null ? cPer.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tcsb06Per)) {
            return false;
        }
        Tcsb06Per other = (Tcsb06Per) object;
        if ((this.cPer == null && other.cPer != null) || (this.cPer != null && !this.cPer.equals(other.cPer))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.csb.ejb.Tcsb06Per[ cPer=" + cPer + " ]";
    }
    
}
