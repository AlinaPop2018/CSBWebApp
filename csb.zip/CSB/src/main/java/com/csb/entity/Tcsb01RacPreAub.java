/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csb.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author utente
 */
@Entity
@Table(name = "TCSB01_RAC_PRE_AUB")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tcsb01RacPreAub.findAll", query = "SELECT t FROM Tcsb01RacPreAub t")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByCRacPreAub", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.cRacPreAub = :cRacPreAub")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByNCnt", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.nCnt = :nCnt")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByTDesCnt", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.tDesCnt = :tDesCnt")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByNFto", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.nFto = :nFto")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByCTipCnt", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.cTipCnt = :cTipCnt")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByIRac", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.iRac = :iRac")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByDLetFil", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.dLetFil = :dLetFil")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByFEla", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.fEla = :fEla")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByTFonPvzFil", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.tFonPvzFil = :tFonPvzFil")
    , @NamedQuery(name = "Tcsb01RacPreAub.findByFCan", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.fCan = :fCan")
	, @NamedQuery(name = "Tcsb01RacPreAub.maxProgresivoFile", query = "SELECT max(pFl) FROM Tcsb01RacPreAub t ")
    , @NamedQuery(name = "Tcsb01RacPreAub.maxProgresivoElabFile", query = "SELECT max(pFl) FROM Tcsb01RacPreAub t WHERE t.fEla = :fEla")
	, @NamedQuery(name = "Tcsb01RacPreAub.findAllNonElabFile", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.fEla = :fEla and t.pFl = :pFl")
    , @NamedQuery(name = "Tcsb01RacPreAub.findAllNonElab", query = "SELECT t FROM Tcsb01RacPreAub t WHERE t.fEla = :fEla")})
public class Tcsb01RacPreAub implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "C_RAC_PRE_AUB")
    private Long cRacPreAub;
    @Column(name = "P_FL")
    private Long pFl;
    @Size(max = 40)
    @Column(name = "N_CNT")
    private String nCnt;
    @Size(max = 255)
    @Column(name = "T_DES_CNT")
    private String tDesCnt;
    @Size(max = 20)
    @Column(name = "N_FTO")
    private String nFto;
    @Size(max = 20)
    @Column(name = "C_TIP_CNT")
    private String cTipCnt;
    @Column(name = "I_RAC")
    private Float iRac;
    @Column(name = "D_LET_FIL")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dLetFil;
    @Column(name = "F_ELA")
    private Short fEla;
    @Size(max = 40)
    @Column(name = "T_FON_PVZ_FIL")
    private String tFonPvzFil;
    @Column(name = "F_CAN")
    private Short fCan;

    public Tcsb01RacPreAub() {
    }

    public Tcsb01RacPreAub(Long cRacPreAub) {
        this.cRacPreAub = cRacPreAub;
    }

    public Long getCRacPreAub() {
        return cRacPreAub;
    }

    public void setCRacPreAub(Long cRacPreAub) {
        this.cRacPreAub = cRacPreAub;
    }
    
    public Long getPFl() {
		return pFl;
	}

	public void setPFl(Long pFl) {
		this.pFl = pFl;
	}

	public String getNCnt() {
        return nCnt;
    }

    public void setNCnt(String nCnt) {
        this.nCnt = nCnt;
    }

    public String getTDesCnt() {
        return tDesCnt;
    }

    public void setTDesCnt(String tDesCnt) {
        this.tDesCnt = tDesCnt;
    }

    public String getNFto() {
        return nFto;
    }

    public void setNFto(String nFto) {
        this.nFto = nFto;
    }

    public String getCTipCnt() {
        return cTipCnt;
    }

    public void setCTipCnt(String cTipCnt) {
        this.cTipCnt = cTipCnt;
    }

    public Float getIRac() {
        return iRac;
    }

    public void setIRac(Float iRac) {
        this.iRac = iRac;
    }

    public Date getDLetFil() {
        return dLetFil;
    }

    public void setDLetFil(Date dLetFil) {
        this.dLetFil = dLetFil;
    }

    public Short getFEla() {
        return fEla;
    }

    public void setFEla(Short fEla) {
        this.fEla = fEla;
    }

    public String getTFonPvzFil() {
        return tFonPvzFil;
    }

    public void setTFonPvzFil(String tFonPvzFil) {
        this.tFonPvzFil = tFonPvzFil;
    }

    public Short getFCan() {
        return fCan;
    }

    public void setFCan(Short fCan) {
        this.fCan = fCan;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cRacPreAub != null ? cRacPreAub.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tcsb01RacPreAub)) {
            return false;
        }
        Tcsb01RacPreAub other = (Tcsb01RacPreAub) object;
        if ((this.cRacPreAub == null && other.cRacPreAub != null) || (this.cRacPreAub != null && !this.cRacPreAub.equals(other.cRacPreAub))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.csb.ejb.Tcsb01RacPreAub[ cRacPreAub=" + cRacPreAub + " ]";
    }
    
}
