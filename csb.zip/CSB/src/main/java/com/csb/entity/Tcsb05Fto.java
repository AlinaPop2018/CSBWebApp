/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csb.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author utente
 */
@Entity
@Table(name = "TCSB05_FTO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tcsb05Fto.findAll", query = "SELECT t FROM Tcsb05Fto t")
    , @NamedQuery(name = "Tcsb05Fto.findByCFto", query = "SELECT t FROM Tcsb05Fto t WHERE t.cFto = :cFto")
    , @NamedQuery(name = "Tcsb05Fto.findByTDesFto", query = "SELECT t FROM Tcsb05Fto t WHERE t.tDesFto = :tDesFto")})
public class Tcsb05Fto implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "C_FTO")
    private String cFto;
    @Size(max = 255)
    @Column(name = "T_DES_FTO")
    private String tDesFto;
    @OneToMany(mappedBy = "cFto")
    private Collection<Tcsb02Reg> tcsb02RegCollection;

    public Tcsb05Fto() {
    }

    public Tcsb05Fto(String cFto) {
        this.cFto = cFto;
    }

    public String getCFto() {
        return cFto;
    }

    public void setCFto(String cFto) {
        this.cFto = cFto;
    }

    public String getTDesFto() {
        return tDesFto;
    }

    public void setTDesFto(String tDesFto) {
        this.tDesFto = tDesFto;
    }

    @XmlTransient
    public Collection<Tcsb02Reg> getTcsb02RegCollection() {
        return tcsb02RegCollection;
    }

    public void setTcsb02RegCollection(Collection<Tcsb02Reg> tcsb02RegCollection) {
        this.tcsb02RegCollection = tcsb02RegCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cFto != null ? cFto.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tcsb05Fto)) {
            return false;
        }
        Tcsb05Fto other = (Tcsb05Fto) object;
        if ((this.cFto == null && other.cFto != null) || (this.cFto != null && !this.cFto.equals(other.cFto))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.csb.ejb.Tcsb05Fto[ cFto=" + cFto + " ]";
    }
    
}
