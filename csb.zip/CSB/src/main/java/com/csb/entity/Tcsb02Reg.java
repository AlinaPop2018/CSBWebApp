/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csb.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author utente
 */
@Entity
@Table(name = "TCSB02_REG")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tcsb02Reg.findAll", query = "SELECT t FROM Tcsb02Reg t")
    , @NamedQuery(name = "Tcsb02Reg.findByCRgl", query = "SELECT t FROM Tcsb02Reg t WHERE t.cRgl = :cRgl")
    , @NamedQuery(name = "Tcsb02Reg.findByDIniVal", query = "SELECT t FROM Tcsb02Reg t WHERE t.dIniVal = :dIniVal")
    , @NamedQuery(name = "Tcsb02Reg.findByTCntCog", query = "SELECT t FROM Tcsb02Reg t WHERE t.tCntCog = :tCntCog")
    , @NamedQuery(name = "Tcsb02Reg.findByNPrgRgl", query = "SELECT t FROM Tcsb02Reg t WHERE t.nPrgRgl = :nPrgRgl")
    , @NamedQuery(name = "Tcsb02Reg.findByIRgl", query = "SELECT t FROM Tcsb02Reg t WHERE t.iRgl = :iRgl")
    , @NamedQuery(name = "Tcsb02Reg.findByTNot", query = "SELECT t FROM Tcsb02Reg t WHERE t.tNot = :tNot")
    , @NamedQuery(name = "Tcsb02Reg.findByCAtt", query = "SELECT t.iRgl FROM Tcsb02Reg t WHERE t.cAtt = :cAtt and t.cFto = :cFto")
    , @NamedQuery(name = "Tcsb02Reg.findByCFto", query = "SELECT t FROM Tcsb02Reg t WHERE t.cFto = :cFto")})
public class Tcsb02Reg implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "C_RGL")
    private Long cRgl;
    @Column(name = "D_INI_VAL")
    @Temporal(TemporalType.DATE)
    private Date dIniVal;
    @Size(max = 10)
    @Column(name = "T_CNT_COG")
    private String tCntCog;
    @Column(name = "N_PRG_RGL")
    private Long nPrgRgl;
    @Size(max = 20)
    @Column(name = "I_RGL")
    private String iRgl;
    @Size(max = 1000)
    @Column(name = "T_NOT")
    private String tNot;
    @JoinColumn(name = "C_ATT", referencedColumnName = "C_ATT")
    @ManyToOne
    private Tcsb04Att cAtt;
    @JoinColumn(name = "C_FTO", referencedColumnName = "C_FTO")
    @ManyToOne
    private Tcsb05Fto cFto;

    public Tcsb02Reg() {
    }

    public Tcsb02Reg(Long cRgl) {
        this.cRgl = cRgl;
    }

    public Long getCRgl() {
        return cRgl;
    }

    public void setCRgl(Long cRgl) {
        this.cRgl = cRgl;
    }

    public Date getDIniVal() {
        return dIniVal;
    }

    public void setDIniVal(Date dIniVal) {
        this.dIniVal = dIniVal;
    }

    public String getTCntCog() {
        return tCntCog;
    }

    public void setTCntCog(String tCntCog) {
        this.tCntCog = tCntCog;
    }

    public Long getNPrgRgl() {
        return nPrgRgl;
    }

    public void setNPrgRgl(Long nPrgRgl) {
        this.nPrgRgl = nPrgRgl;
    }

    public String getIRgl() {
        return iRgl;
    }

    public void setIRgl(String iRgl) {
        this.iRgl = iRgl;
    }

    public String getTNot() {
        return tNot;
    }

    public void setTNot(String tNot) {
        this.tNot = tNot;
    }

    public Tcsb04Att getCAtt() {
        return cAtt;
    }

    public void setCAtt(Tcsb04Att cAtt) {
        this.cAtt = cAtt;
    }

    public Tcsb05Fto getCFto() {
        return cFto;
    }

    public void setCFto(Tcsb05Fto cFto) {
        this.cFto = cFto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cRgl != null ? cRgl.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tcsb02Reg)) {
            return false;
        }
        Tcsb02Reg other = (Tcsb02Reg) object;
        if ((this.cRgl == null && other.cRgl != null) || (this.cRgl != null && !this.cRgl.equals(other.cRgl))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.csb.ejb.Tcsb02Reg[ cRgl=" + cRgl + " ]";
    }
    
}
