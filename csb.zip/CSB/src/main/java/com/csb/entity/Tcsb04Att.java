/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csb.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author utente
 */
@Entity
@Table(name = "TCSB04_ATT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tcsb04Att.findAll", query = "SELECT t FROM Tcsb04Att t")
    , @NamedQuery(name = "Tcsb04Att.findByCAtt", query = "SELECT t FROM Tcsb04Att t WHERE t.cAtt = :cAtt")
    , @NamedQuery(name = "Tcsb04Att.findByTDesAtt", query = "SELECT t FROM Tcsb04Att t WHERE t.tDesAtt = :tDesAtt")})
public class Tcsb04Att implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "C_ATT")
    private String cAtt;
    @Size(max = 255)
    @Column(name = "T_DES_ATT")
    private String tDesAtt;
    @OneToMany(mappedBy = "cAtt")
    private Collection<Tcsb02Reg> tcsb02RegCollection;

    public Tcsb04Att() {
    }

    public Tcsb04Att(String cAtt) {
        this.cAtt = cAtt;
    }

    public String getCAtt() {
        return cAtt;
    }

    public void setCAtt(String cAtt) {
        this.cAtt = cAtt;
    }

    public String getTDesAtt() {
        return tDesAtt;
    }

    public void setTDesAtt(String tDesAtt) {
        this.tDesAtt = tDesAtt;
    }

    @XmlTransient
    public Collection<Tcsb02Reg> getTcsb02RegCollection() {
        return tcsb02RegCollection;
    }

    public void setTcsb02RegCollection(Collection<Tcsb02Reg> tcsb02RegCollection) {
        this.tcsb02RegCollection = tcsb02RegCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cAtt != null ? cAtt.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tcsb04Att)) {
            return false;
        }
        Tcsb04Att other = (Tcsb04Att) object;
        if ((this.cAtt == null && other.cAtt != null) || (this.cAtt != null && !this.cAtt.equals(other.cAtt))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.csb.ejb.Tcsb04Att[ cAtt=" + cAtt + " ]";
    }
    
}
