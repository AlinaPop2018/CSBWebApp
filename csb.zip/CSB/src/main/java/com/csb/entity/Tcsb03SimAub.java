/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csb.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author utente
 */
@Entity
@Table(name = "TCSB03_SIM_AUB")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tcsb03SimAub.findAll", query = "SELECT t FROM Tcsb03SimAub t")
    , @NamedQuery(name = "Tcsb03SimAub.findByCSim", query = "SELECT t FROM Tcsb03SimAub t WHERE t.cSim = :cSim")
    , @NamedQuery(name = "Tcsb03SimAub.findByCFrmTec", query = "SELECT t FROM Tcsb03SimAub t WHERE t.cFrmTec = :cFrmTec")
    , @NamedQuery(name = "Tcsb03SimAub.findByCRes", query = "SELECT t FROM Tcsb03SimAub t WHERE t.cRes = :cRes")
    , @NamedQuery(name = "Tcsb03SimAub.findByNDur", query = "SELECT t FROM Tcsb03SimAub t WHERE t.nDur = :nDur")
    , @NamedQuery(name = "Tcsb03SimAub.findByCCmp", query = "SELECT t FROM Tcsb03SimAub t WHERE t.cCmp = :cCmp")
    , @NamedQuery(name = "Tcsb03SimAub.findByTValCmp", query = "SELECT t FROM Tcsb03SimAub t WHERE t.tValCmp = :tValCmp")
    , @NamedQuery(name = "Tcsb03SimAub.findByTSegCmp", query = "SELECT t FROM Tcsb03SimAub t WHERE t.tSegCmp = :tSegCmp")
    , @NamedQuery(name = "Tcsb03SimAub.findByTFinVal", query = "SELECT t FROM Tcsb03SimAub t WHERE t.tFinVal = :tFinVal")
    , @NamedQuery(name = "Tcsb03SimAub.findByNOrdKeyPum", query = "SELECT t FROM Tcsb03SimAub t WHERE t.nOrdKeyPum = :nOrdKeyPum")
    , @NamedQuery(name = "Tcsb03SimAub.findByTPrgRap", query = "SELECT t FROM Tcsb03SimAub t WHERE t.tPrgRap = :tPrgRap")
    , @NamedQuery(name = "Tcsb03SimAub.findByTPrgPta", query = "SELECT t FROM Tcsb03SimAub t WHERE t.tPrgPta = :tPrgPta")
    , @NamedQuery(name = "Tcsb03SimAub.findByCUniInf", query = "SELECT t FROM Tcsb03SimAub t WHERE t.cUniInf = :cUniInf")
    , @NamedQuery(name = "Tcsb03SimAub.findByTDis", query = "SELECT t FROM Tcsb03SimAub t WHERE t.tDis = :tDis")
    , @NamedQuery(name = "Tcsb03SimAub.findByDElaFil", query = "SELECT t FROM Tcsb03SimAub t WHERE t.dElaFil = :dElaFil")
    , @NamedQuery(name = "Tcsb03SimAub.findByFFilEla", query = "SELECT t FROM Tcsb03SimAub t WHERE t.fFilEla = :fFilEla")
    , @NamedQuery(name = "Tcsb03SimAub.findByTFonPvzFil", query = "SELECT t FROM Tcsb03SimAub t WHERE t.tFonPvzFil = :tFonPvzFil")
    , @NamedQuery(name = "Tcsb03SimAub.findByFRcdCan", query = "SELECT t FROM Tcsb03SimAub t WHERE t.fRcdCan = :fRcdCan")
    , @NamedQuery(name = "Tcsb03SimAub.findByPFl", query = "SELECT t FROM Tcsb03SimAub t WHERE t.pFl = :pFl order by cSim")
    , @NamedQuery(name = "Tcsb03SimAub.findByDRcdCan", query = "SELECT t FROM Tcsb03SimAub t WHERE t.dRcdCan = :dRcdCan")})
public class Tcsb03SimAub implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "C_SIM")
    private Long cSim;
    @Column(name = "P_FL")
    private Long pFl;
    @Size(max = 8)
    @Column(name = "C_FRM_TEC")
    private String cFrmTec;
    @Column(name = "C_RES")
    private Short cRes;
    @Column(name = "N_DUR")
    private Short nDur;
    @Size(max = 20)
    @Column(name = "C_CMP")
    private String cCmp;
    @Size(max = 20)
    @Column(name = "T_VAL_CMP")
    private String tValCmp;
    @Column(name = "T_SEG_CMP")
    private Character tSegCmp;
    @Column(name = "T_FIN_VAL")
    private Character tFinVal;
    @Column(name = "N_ORD_KEY_PUM")
    private Short nOrdKeyPum;
    @Size(max = 20)
    @Column(name = "T_PRG_RAP")
    private String tPrgRap;
    @Size(max = 20)
    @Column(name = "T_PRG_PTA")
    private String tPrgPta;
    @Column(name = "C_UNI_INF")
    private Long cUniInf;
    @Size(max = 3)
    @Column(name = "T_DIS")
    private String tDis;
    @Column(name = "D_ELA_FIL")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dElaFil;
    @Column(name = "F_FIL_ELA")
    private Long fFilEla;
    @Size(max = 40)
    @Column(name = "T_FON_PVZ_FIL")
    private String tFonPvzFil;
    @Column(name = "F_RCD_CAN")
    private Character fRcdCan;
    @Column(name = "D_RCD_CAN")
    @Temporal(TemporalType.DATE)
    private Date dRcdCan;
    @JoinColumn(name = "C_PER_RIF", referencedColumnName = "C_PER")
    @ManyToOne
    private Tcsb06Per cPerRif;

    public Tcsb03SimAub() {
    }

    public Tcsb03SimAub(Long cSim) {
        this.cSim = cSim;
    }

    public Long getCSim() {
        return cSim;
    }

    public void setCSim(Long cSim) {
        this.cSim = cSim;
    }
    
    public Long getPFl() {
		return pFl;
	}

	public void setPFl(Long pFl) {
		this.pFl = pFl;
	}

    public String getCFrmTec() {
        return cFrmTec;
    }

    public void setCFrmTec(String cFrmTec) {
        this.cFrmTec = cFrmTec;
    }

    public Short getCRes() {
        return cRes;
    }

    public void setCRes(Short cRes) {
        this.cRes = cRes;
    }

    public Short getNDur() {
        return nDur;
    }

    public void setNDur(Short nDur) {
        this.nDur = nDur;
    }

    public String getCCmp() {
        return cCmp;
    }

    public void setCCmp(String cCmp) {
        this.cCmp = cCmp;
    }

    public String getTValCmp() {
        return tValCmp;
    }

    public void setTValCmp(String tValCmp) {
        this.tValCmp = tValCmp;
    }

    public Character getTSegCmp() {
        return tSegCmp;
    }

    public void setTSegCmp(Character tSegCmp) {
        this.tSegCmp = tSegCmp;
    }

    public Character getTFinVal() {
        return tFinVal;
    }

    public void setTFinVal(Character tFinVal) {
        this.tFinVal = tFinVal;
    }

    public Short getNOrdKeyPum() {
        return nOrdKeyPum;
    }

    public void setNOrdKeyPum(Short nOrdKeyPum) {
        this.nOrdKeyPum = nOrdKeyPum;
    }

    public String getTPrgRap() {
        return tPrgRap;
    }

    public void setTPrgRap(String tPrgRap) {
        this.tPrgRap = tPrgRap;
    }

    public String getTPrgPta() {
        return tPrgPta;
    }

    public void setTPrgPta(String tPrgPta) {
        this.tPrgPta = tPrgPta;
    }

    public Long getCUniInf() {
        return cUniInf;
    }

    public void setCUniInf(Long cUniInf) {
        this.cUniInf = cUniInf;
    }

    public String getTDis() {
        return tDis;
    }

    public void setTDis(String tDis) {
        this.tDis = tDis;
    }

    public Date getDElaFil() {
        return dElaFil;
    }

    public void setDElaFil(Date dElaFil) {
        this.dElaFil = dElaFil;
    }

    public Long getFFilEla() {
        return fFilEla;
    }

    public void setFFilEla(Long fFilEla) {
        this.fFilEla = fFilEla;
    }

    public String getTFonPvzFil() {
        return tFonPvzFil;
    }

    public void setTFonPvzFil(String tFonPvzFil) {
        this.tFonPvzFil = tFonPvzFil;
    }

    public Character getFRcdCan() {
        return fRcdCan;
    }

    public void setFRcdCan(Character fRcdCan) {
        this.fRcdCan = fRcdCan;
    }

    public Date getDRcdCan() {
        return dRcdCan;
    }

    public void setDRcdCan(Date dRcdCan) {
        this.dRcdCan = dRcdCan;
    }

    public Tcsb06Per getCPerRif() {
        return cPerRif;
    }

    public void setCPerRif(Tcsb06Per cPerRif) {
        this.cPerRif = cPerRif;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cSim != null ? cSim.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tcsb03SimAub)) {
            return false;
        }
        Tcsb03SimAub other = (Tcsb03SimAub) object;
        if ((this.cSim == null && other.cSim != null) || (this.cSim != null && !this.cSim.equals(other.cSim))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.csb.ejb.Tcsb03SimAub[ cSim=" + cSim + " ]";
    }
    
}
